module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: { extend: {
    colors: { ivory:"#FAF8F1", navy:"#07182D", navySoft:"#102B4F", gold:"#C7A65A", goldLight:"#E7D09A" },
    fontFamily: { serif:["Cormorant Garamond","serif"], script:["Great Vibes","cursive"], sans:["Montserrat","sans-serif"] }
  }},
  plugins: []
};
