export default function Monogram(){
  return (
    <div className="relative mx-auto flex h-40 w-40 items-center justify-center">
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full">
        <defs><linearGradient id="gold" x1="0" x2="1"><stop offset="0%" stopColor="#8b6b2e"/><stop offset="45%" stopColor="#E7D09A"/><stop offset="100%" stopColor="#C7A65A"/></linearGradient></defs>
        <circle cx="100" cy="100" r="76" fill="none" stroke="url(#gold)" strokeWidth="2" opacity=".9"/>
        <path d="M43 116C30 86 43 54 72 40" fill="none" stroke="url(#gold)" strokeWidth="3" strokeLinecap="round"/>
        <path d="M157 116c13-30 0-62-29-76" fill="none" stroke="url(#gold)" strokeWidth="3" strokeLinecap="round"/>
        <path d="M100 19l5 13 13 5-13 5-5 13-5-13-13-5 13-5 5-13z" fill="url(#gold)" opacity=".9"/>
        <path d="M100 162l4 9 9 4-9 4-4 9-4-9-9-4 9-4 4-9z" fill="url(#gold)" opacity=".9"/>
      </svg>
      <div className="relative font-serif text-7xl font-semibold leading-none gold-text"><span className="-mr-3">G</span><span className="-ml-3">S</span></div>
    </div>
  );
}
