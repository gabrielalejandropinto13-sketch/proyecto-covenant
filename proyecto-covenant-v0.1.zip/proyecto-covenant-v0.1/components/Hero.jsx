"use client";
import { motion } from "framer-motion";
import Monogram from "./Monogram";

const fade = { hidden:{opacity:0,y:18}, show:{opacity:1,y:0} };

export default function Hero(){
  return (
    <main className="velvet relative flex min-h-screen items-center justify-center overflow-hidden px-6 text-center">
      <div className="particle left-[12%] top-[18%]" />
      <div className="particle left-[80%] top-[16%] [animation-delay:1.5s]" />
      <div className="particle left-[22%] top-[74%] [animation-delay:2.5s]" />
      <div className="particle left-[70%] top-[68%] [animation-delay:3.3s]" />
      <motion.section initial="hidden" animate="show" transition={{staggerChildren:.55,delayChildren:.25}} className="relative z-10 w-full max-w-sm">
        <motion.div variants={fade} transition={{duration:1.2}}><Monogram /></motion.div>
        <motion.p variants={fade} transition={{duration:1}} className="mt-8 font-serif text-3xl tracking-[0.18em] text-goldLight">GABRIEL & SATHYA</motion.p>
        <motion.div variants={fade} transition={{duration:1}} className="mx-auto my-6 flex w-44 items-center gap-3 text-gold">
          <span className="h-px flex-1 bg-gold/70"/><span className="text-sm">✦</span><span className="h-px flex-1 bg-gold/70"/>
        </motion.div>
        <motion.h1 variants={fade} transition={{duration:1}} className="font-serif text-xl uppercase tracking-[0.22em] text-ivory">Un pacto delante de Dios</motion.h1>
        <motion.p variants={fade} transition={{duration:1}} className="mt-5 font-serif text-2xl italic text-goldLight">El comienzo de una promesa eterna</motion.p>
        <motion.p variants={fade} transition={{duration:1}} className="mt-7 text-xs uppercase tracking-[0.28em] text-ivory/70">11 de octubre de 2026</motion.p>
        <motion.div variants={fade} transition={{duration:1}} className="mt-14 text-goldLight">
          <div className="mx-auto mb-3 h-10 w-px bg-gradient-to-b from-goldLight to-transparent"/>
          <p className="text-[11px] uppercase tracking-[0.25em] text-ivory/65">Deslizá para comenzar</p>
        </motion.div>
      </motion.section>
    </main>
  );
}
