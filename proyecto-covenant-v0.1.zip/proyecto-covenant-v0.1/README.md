# Proyecto Covenant

Sitio oficial de la boda de Gabriel & Sathya.

## v0.1
Pantalla Hero mobile-first.
