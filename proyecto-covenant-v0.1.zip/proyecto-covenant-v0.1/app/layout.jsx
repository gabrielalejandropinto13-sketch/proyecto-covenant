import "./globals.css";
export const metadata = { title: "Gabriel & Sathya", description: "Un pacto delante de Dios" };
export default function RootLayout({ children }) {
  return <html lang="es"><body>{children}</body></html>;
}
